# TEXARI V0.3 Evaluation

Native Android evaluation build focused on the consumer experience.

## V0.3 changes
- First-run onboarding and local user profile
- Personalized Home with greeting and avatar
- Quick actions for photo, invoice, PDF and note
- "What matters today" card for relevant deadlines
- Monthly spending summary on Home
- Context previews and recent items
- Profile/preferences screen
- Existing V0.2 OCR, editable classification, expenses, contexts and Ask flow retained

## Privacy in this evaluation
Profile, documents metadata and spending data are stored locally on the device. There is no cloud account or cross-device synchronization in V0.3.
