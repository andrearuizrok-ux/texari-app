# TEXARI V0.8 — Cloud Free Beta (Spark)

This evaluation source builds on V0.7.2 and prepares TEXARI for a small real-user beta without requiring a paid Firebase plan.

## What is new in V0.8
- Real Firebase Email/Password accounts.
- Structured Cloud sync through Cloud Firestore: finance data, debts/installments, OCR text, dates, amounts, statuses, categories, budgets and preferences.
- Explicit **Sync now** writes the latest structured state to the authenticated user's private Firestore document.
- Normal edits use a lightweight automatic data sync when the user is signed in.
- **Restore from Cloud** restores structured data on another installation/device.
- Original photos and PDFs stay in TEXARI's private local app storage in this free beta. They are not uploaded to Firebase Storage.
- Cloud account deletion removes the user's Firestore state and then the Firebase Auth account. Local files remain on the device.
- Cloud schema version is 8 with `cloudMode = SPARK_DATA_ONLY`.
- Private-beta center added to Profile. Beta testers see TEXARI Plus unlocked and can indicate whether they would pay for it.
- Local beta metrics stay on-device and are only shared when the tester explicitly uses **Share beta feedback**.
- Test pricing is shown as a research hypothesis only: €4.99/month or €44.99/year. No payment system is active.
- Consumer wording, debts/installments, Back navigation and V0.7.2 original-document previews remain intact.

## Firebase setup for the free beta
1. Firebase project: TEXARI.
2. Android package: `app.texari.evaluation`.
3. `app/google-services.json` is included in the configured beta source.
4. Enable Firebase Authentication -> Email/Password.
5. Create Cloud Firestore.
6. Publish `firebase/firestore.rules`.
7. Firebase Storage is intentionally not required for this beta.

The included Firestore rule restricts `/users/{userId}` to the authenticated user whose Firebase UID matches `userId`.

## Original files
Photos/PDFs imported into TEXARI remain on the device where they were imported. A restored record can still contain its OCR/data and the original file name, but the original preview is unavailable on a different device until a future user-owned or paid file-storage option is enabled.

## Automatic monthly report backend
The Firebase Functions scaffold remains included as future backend work. It is not deployed automatically by the APK build and automatic email delivery is not claimed as active in this beta.
