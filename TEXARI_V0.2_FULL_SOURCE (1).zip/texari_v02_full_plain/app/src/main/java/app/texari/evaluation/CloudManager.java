package app.texari.evaluation;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

/**
 * Firebase adapter for TEXARI Cloud Free Beta.
 *
 * V0.8 uses Firebase Authentication + Cloud Firestore only, so the beta can run
 * on Firebase's Spark plan without enabling paid Cloud Storage. Structured data,
 * OCR text, dates, amounts, statuses and preferences can sync between devices.
 * Original photos/PDFs remain in TEXARI's private local storage on the device
 * where they were imported.
 */
public class CloudManager {
    public interface Callback {
        void onResult(boolean ok, String message);
    }

    private FirebaseApp app;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    public CloudManager(Context context) {
        Context appContext = context.getApplicationContext();
        try {
            app = FirebaseApp.initializeApp(appContext);
            if (app != null) {
                auth = FirebaseAuth.getInstance(app);
                db = FirebaseFirestore.getInstance(app);
            }
        } catch (Throwable ignored) {
            app = null;
            auth = null;
            db = null;
        }
    }

    public boolean isConfigured() {
        return app != null && auth != null && db != null;
    }

    public boolean isSignedIn() {
        return isConfigured() && auth.getCurrentUser() != null;
    }

    public String email() {
        FirebaseUser u = isConfigured() ? auth.getCurrentUser() : null;
        return u == null || u.getEmail() == null ? "" : u.getEmail();
    }

    public String uid() {
        FirebaseUser u = isConfigured() ? auth.getCurrentUser() : null;
        return u == null ? "" : u.getUid();
    }

    public void signUp(String email, String password, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> cb.onResult(true, "SIGNED_UP"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void signIn(String email, String password, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> cb.onResult(true, "SIGNED_IN"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void sendPasswordReset(String email, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.sendPasswordResetEmail(email)
                .addOnSuccessListener(v -> cb.onResult(true, "RESET_SENT"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void signOut() {
        if (isConfigured()) auth.signOut();
    }

    /**
     * Kept as the public explicit sync entry point. In the Spark beta this syncs
     * structured data only; original files intentionally stay local.
     */
    public void syncState(SharedPreferences prefs, List<TexariItem> items, Callback cb) {
        syncStructuredState(prefs, items, true, cb);
    }

    /** Lightweight structured sync used after normal edits. */
    public void syncStateDataOnly(SharedPreferences prefs, List<TexariItem> items, Callback cb) {
        syncStructuredState(prefs, items, false, cb);
    }

    private void syncStructuredState(SharedPreferences prefs, List<TexariItem> items, boolean explicitSync, Callback cb) {
        if (!isSignedIn()) {
            if (cb != null) cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }

        JSONArray arr = new JSONArray();
        for (TexariItem i : items) arr.put(i.toJson());

        Map<String, Object> state = new HashMap<>();
        state.put("uid", uid());
        state.put("email", email());
        state.put("name", prefs.getString("profile_name", ""));
        state.put("language", prefs.getString("language", "IT"));
        state.put("currency", prefs.getString("currency", "EUR"));
        state.put("dateFormat", prefs.getString("date_format", "DMY"));
        state.put("reportEnabled", prefs.getBoolean("monthly_report_enabled", false));
        state.put("reportDay", prefs.getInt("monthly_report_day", 1));
        state.put("reportFormat", prefs.getString("monthly_report_format", "PDF"));
        state.put("reportEmail", prefs.getString("profile_email", email()));
        state.put("timezone", TimeZone.getDefault().getID());
        state.put("itemsJson", arr.toString());
        state.put("learnedCategories", prefs.getString("learned_categories", "{}"));
        state.put("budgets", prefs.getString("budgets", "{}"));
        state.put("schemaVersion", 8);
        state.put("cloudMode", "SPARK_DATA_ONLY");
        state.put("updatedAt", FieldValue.serverTimestamp());
        if (explicitSync) state.put("lastManualSyncAt", FieldValue.serverTimestamp());

        db.collection("users").document(uid())
                .set(state, SetOptions.merge())
                .addOnSuccessListener(v -> {
                    long now = System.currentTimeMillis();
                    SharedPreferences.Editor pe = prefs.edit().putLong("cloud_last_data_sync_ms", now);
                    if (explicitSync) pe.putLong("cloud_last_sync_ms", now);
                    pe.apply();
                    if (cb != null) cb.onResult(true, "SYNCED_DATA_ONLY");
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onResult(false, safeMessage(e));
                });
    }

    /** Restore structured state. Original files are not part of the Spark backup. */
    public void restoreState(SharedPreferences prefs, Callback cb) {
        if (!isSignedIn()) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        db.collection("users").document(uid()).get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists()) {
                        cb.onResult(false, "NO_CLOUD_BACKUP");
                        return;
                    }
                    applyDocument(doc, prefs);
                    long now = System.currentTimeMillis();
                    prefs.edit().putLong("cloud_last_sync_ms", now)
                            .putLong("cloud_last_data_sync_ms", now).apply();
                    cb.onResult(true, "RESTORED_DATA_ONLY");
                })
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    private void applyDocument(DocumentSnapshot doc, SharedPreferences prefs) {
        SharedPreferences.Editor e = prefs.edit();
        putString(doc, e, "name", "profile_name");
        putString(doc, e, "language", "language");
        putString(doc, e, "currency", "currency");
        putString(doc, e, "dateFormat", "date_format");
        putString(doc, e, "reportFormat", "monthly_report_format");
        putString(doc, e, "reportEmail", "profile_email");
        putString(doc, e, "itemsJson", "items");
        putString(doc, e, "learnedCategories", "learned_categories");
        putString(doc, e, "budgets", "budgets");
        Boolean enabled = doc.getBoolean("reportEnabled");
        if (enabled != null) e.putBoolean("monthly_report_enabled", enabled);
        Long day = doc.getLong("reportDay");
        if (day != null) e.putInt("monthly_report_day", Math.max(1, Math.min(28, day.intValue())));
        e.putBoolean("onboarding_done", true)
                .putBoolean("v04_setup_done", true)
                .putBoolean("v05_setup_done", true)
                .putBoolean("v06_setup_done", true)
                .putBoolean("v08_setup_done", true)
                .apply();
    }

    private static void putString(DocumentSnapshot doc, SharedPreferences.Editor e, String cloudKey, String prefKey) {
        String v = doc.getString(cloudKey);
        if (v != null) e.putString(prefKey, v);
    }

    /** Delete Firestore state, then the Firebase Auth account. Local files remain on-device. */
    public void deleteCloudAccount(Callback cb) {
        if (!isSignedIn()) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        final String userId = user.getUid();
        db.collection("users").document(userId).delete()
                .continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        Exception e = task.getException();
                        if (e != null) throw e;
                        throw new IllegalStateException("Cloud state deletion failed");
                    }
                    return user.delete();
                })
                .addOnSuccessListener(v -> cb.onResult(true, "DELETED"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    private static String safeMessage(Throwable t) {
        String m = t == null ? "Cloud error" : t.getMessage();
        return m == null || m.trim().isEmpty() ? "Cloud error" : m;
    }
}
