package app.texari;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public class MonthlyReportReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("texari_v02", Context.MODE_PRIVATE);
        String language = prefs.getString("language", "ES");
        String title = "IT".equals(language) ? "Il tuo report TEXARI è pronto" : "EN".equals(language) ? "Your TEXARI report is ready" : "Tu reporte TEXARI está listo";
        String text = "IT".equals(language) ? "Apri Spese → Report per scaricarlo, condividerlo o inviarlo via email." : "EN".equals(language) ? "Open Expenses → Report to download, share or email it." : "Abre Gastos → Reporte para descargarlo, compartirlo o enviarlo por correo.";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            String channelId = "texari_monthly_reports";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(channelId, "TEXARI Reports", NotificationManager.IMPORTANCE_DEFAULT);
                nm.createNotificationChannel(channel);
            }
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent content = PendingIntent.getActivity(context, 70052, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(context, channelId) : new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.ic_menu_save)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                    .setContentIntent(content)
                    .setAutoCancel(true);
            nm.notify(70053, b.build());
        }
        MonthlyReportScheduler.scheduleFromPrefs(context);
    }
}
