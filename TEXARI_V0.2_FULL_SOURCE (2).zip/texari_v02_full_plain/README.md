# TEXARI V0.9 — Play Beta preparation

V0.9 moves TEXARI from an evaluation package toward a Google Play beta identity.

## Technical identity
- Application ID / namespace: `app.texari`
- minSdk 23
- compileSdk / targetSdk: 36
- versionCode 12
- versionName 0.9.0
- Android Gradle Plugin 8.9.1
- Gradle 8.11.1

## Firebase
The V0.8 Firebase config was intentionally removed because it belongs to `app.texari.evaluation`. Register a second Android app in the same Firebase project with package `app.texari` and add the new `google-services.json` to `app/`. Authentication and Firestore remain the Cloud services used by the Spark beta; original photos/PDFs remain local.

## Google Play preparation
The source can build a debug APK and a release Android App Bundle (`.aab`). Release signing is supplied only through environment variables so the private upload key never has to be committed to a public repository. See `play/PLAY_RELEASE_CHECKLIST.md`.

## Privacy
The app retains in-app Cloud account deletion. Draft Privacy Policy, account-deletion web page, Data Safety notes and Store listing copy are included under `play/`. Those web pages must be published at real public URLs before Play submission.
