# TEXARI V0.2 Evaluation

Android evaluation build for TEXARI.

## Included in V0.2
- Photo capture and image import
- PDF first-page OCR
- On-device OCR with Google ML Kit
- Editable document classification
- Editable category, subcategory, context and status
- Invoice/receipt amount and due-date extraction
- Monthly expense overview
- Local persistence with SharedPreferences
- Android navigation-bar safe-area handling

## Build
GitHub Actions builds a debug APK and uploads it as `TEXARI-v0.2-evaluation-APK`.
