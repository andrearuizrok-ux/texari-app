# TEXARI — Play Store listing draft

## Name
TEXARI

## Short description
Everything important in your life, organized in context.

## Positioning
TEXARI helps people keep expenses, payments, debts, receipts, documents, deadlines and everyday information together, so they can find what matters when they need it.

## Beta message
Private beta. Cloud sync currently covers structured data. Original photos and PDFs remain on the device in the free beta.

## Assets still needed
- Final 512×512 Play icon
- Feature graphic 1024×500
- Real phone screenshots
- Public privacy-policy URL
- Public account-deletion URL
- Public support email
