package app.texari.evaluation;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

/**
 * Small Firebase adapter for the TEXARI Cloud Beta.
 *
 * The Android app remains buildable without google-services.json. In that case
 * FirebaseApp.initializeApp() returns null and the UI exposes Cloud as "ready to
 * connect" rather than pretending that sync is active.
 */
public class CloudManager {
    public interface Callback {
        void onResult(boolean ok, String message);
    }

    private final Context context;
    private FirebaseApp app;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    public CloudManager(Context context) {
        this.context = context.getApplicationContext();
        try {
            app = FirebaseApp.initializeApp(this.context);
            if (app != null) {
                auth = FirebaseAuth.getInstance(app);
                db = FirebaseFirestore.getInstance(app);
            }
        } catch (Throwable ignored) {
            app = null;
            auth = null;
            db = null;
        }
    }

    public boolean isConfigured() {
        return app != null && auth != null && db != null;
    }

    public boolean isSignedIn() {
        return isConfigured() && auth.getCurrentUser() != null;
    }

    public String email() {
        FirebaseUser u = isConfigured() ? auth.getCurrentUser() : null;
        return u == null || u.getEmail() == null ? "" : u.getEmail();
    }

    public String uid() {
        FirebaseUser u = isConfigured() ? auth.getCurrentUser() : null;
        return u == null ? "" : u.getUid();
    }

    public void signUp(String email, String password, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> cb.onResult(true, "SIGNED_UP"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void signIn(String email, String password, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> cb.onResult(true, "SIGNED_IN"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void sendPasswordReset(String email, Callback cb) {
        if (!isConfigured()) {
            cb.onResult(false, "CLOUD_NOT_CONFIGURED");
            return;
        }
        auth.sendPasswordResetEmail(email)
                .addOnSuccessListener(v -> cb.onResult(true, "RESET_SENT"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    public void signOut() {
        if (isConfigured()) auth.signOut();
    }

    public void syncState(SharedPreferences prefs, List<TexariItem> items, Callback cb) {
        if (!isSignedIn()) {
            if (cb != null) cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        JSONArray arr = new JSONArray();
        for (TexariItem i : items) arr.put(i.toJson());

        Map<String, Object> state = new HashMap<>();
        state.put("uid", uid());
        state.put("email", email());
        state.put("name", prefs.getString("profile_name", ""));
        state.put("language", prefs.getString("language", "IT"));
        state.put("currency", prefs.getString("currency", "EUR"));
        state.put("dateFormat", prefs.getString("date_format", "DMY"));
        state.put("reportEnabled", prefs.getBoolean("monthly_report_enabled", false));
        state.put("reportDay", prefs.getInt("monthly_report_day", 1));
        state.put("reportFormat", prefs.getString("monthly_report_format", "PDF"));
        state.put("reportEmail", prefs.getString("profile_email", email()));
        state.put("timezone", TimeZone.getDefault().getID());
        state.put("itemsJson", arr.toString());
        state.put("learnedCategories", prefs.getString("learned_categories", "{}"));
        state.put("budgets", prefs.getString("budgets", "{}"));
        state.put("updatedAt", FieldValue.serverTimestamp());
        state.put("schemaVersion", 6);

        db.collection("users").document(uid())
                .set(state, SetOptions.merge())
                .addOnSuccessListener(v -> {
                    prefs.edit().putLong("cloud_last_sync_ms", System.currentTimeMillis()).apply();
                    if (cb != null) cb.onResult(true, "SYNCED");
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onResult(false, safeMessage(e));
                });
    }

    public void restoreState(SharedPreferences prefs, Callback cb) {
        if (!isSignedIn()) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        db.collection("users").document(uid()).get()
                .addOnSuccessListener(doc -> applyDocument(doc, prefs, cb))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    private void applyDocument(DocumentSnapshot doc, SharedPreferences prefs, Callback cb) {
        if (!doc.exists()) {
            cb.onResult(false, "NO_CLOUD_BACKUP");
            return;
        }
        SharedPreferences.Editor e = prefs.edit();
        putString(doc, e, "name", "profile_name");
        putString(doc, e, "language", "language");
        putString(doc, e, "currency", "currency");
        putString(doc, e, "dateFormat", "date_format");
        putString(doc, e, "reportFormat", "monthly_report_format");
        putString(doc, e, "reportEmail", "profile_email");
        putString(doc, e, "itemsJson", "items");
        putString(doc, e, "learnedCategories", "learned_categories");
        putString(doc, e, "budgets", "budgets");
        Boolean enabled = doc.getBoolean("reportEnabled");
        if (enabled != null) e.putBoolean("monthly_report_enabled", enabled);
        Long day = doc.getLong("reportDay");
        if (day != null) e.putInt("monthly_report_day", Math.max(1, Math.min(28, day.intValue())));
        e.putBoolean("onboarding_done", true)
                .putBoolean("v04_setup_done", true)
                .putBoolean("v05_setup_done", true)
                .putBoolean("v06_setup_done", true)
                .putLong("cloud_last_sync_ms", System.currentTimeMillis())
                .apply();
        cb.onResult(true, "RESTORED");
    }

    private static void putString(DocumentSnapshot doc, SharedPreferences.Editor e, String cloudKey, String prefKey) {
        String v = doc.getString(cloudKey);
        if (v != null) e.putString(prefKey, v);
    }

    public void deleteCloudAccount(Callback cb) {
        if (!isSignedIn()) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            cb.onResult(false, "NOT_SIGNED_IN");
            return;
        }
        String uid = user.getUid();
        db.collection("users").document(uid).delete()
                .continueWithTask(task -> user.delete())
                .addOnSuccessListener(v -> cb.onResult(true, "DELETED"))
                .addOnFailureListener(e -> cb.onResult(false, safeMessage(e)));
    }

    private static String safeMessage(Throwable t) {
        String m = t == null ? "Cloud error" : t.getMessage();
        return m == null || m.trim().isEmpty() ? "Cloud error" : m;
    }
}
