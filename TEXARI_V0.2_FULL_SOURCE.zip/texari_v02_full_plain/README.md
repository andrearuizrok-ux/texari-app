# TEXARI Android Evaluation V0.5.0

Native Android evaluation build for TEXARI.

## V0.5 focus
- One consistent financial data source for Home, totals, charts, category drill-down, calendar and reports.
- Migration/canonicalization of 2-digit dates such as 05/09/26 so they remain inside the correct month.
- Expense charts aggregate every transaction in the selected period and category.
- Report center with PDF, Excel-compatible XLS and CSV.
- Report actions: Download, Share, Email.
- PDF report includes period summary, paid/due/overdue/to-define totals, category totals and transaction detail.
- Local profile email and monthly report preferences.
- Monthly on-device report reminder.

## Important evaluation limitation
TEXARI Cloud is not connected in this APK. Documents and expenses still live on-device. The app can email a report through the phone's installed email app, but fully automatic email delivery while the app/device is not being used requires the future TEXARI Cloud backend and real authentication.

OCR remains on-device using Google ML Kit.
