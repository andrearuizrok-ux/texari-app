# TEXARI V0.4 evaluation build

Native Android evaluation app focused on a consumer experience and personal finance/context workflows.

## V0.4 changes
- No demo expenses. On first V0.4 launch, the old De'Longhi / Hotel Roma demo records are removed automatically.
- First-run language, currency and date-format setup (Italian / Spanish / English; multiple currencies).
- Clear invoice flow: already paid / to pay / not sure.
- Payment due date, payment method, payment date and reminders.
- Selectable expense categories and subcategories, plus custom categories.
- Edit and delete expenses with totals/charts updating immediately.
- Expense charts with pie, bars and line views; tap chart/category for detail.
- Period filters, calendar history, category filtering and paid/due filtering.
- Export current filtered period as CSV, Excel-readable .xls or PDF.
- Recurring expenses, category budgets, review inbox and global search.
- OCR via on-device ML Kit and editable review before saving.

Data remains local to the device in this evaluation version; cloud accounts/sync are not implemented yet.
