# TEXARI V0.4.1 evaluation build

Native Android evaluation app focused on a consumer experience and personal finance/context workflows.

## V0.4.1 fixes
- Registered invoices/receipts with an amount are automatically treated as financial movements.
- Legacy V0.4 invoice/receipt records that were saved but not flagged as expenses are repaired on upgrade.
- After saving an expense, TEXARI opens the Expenses screen focused on the month of that document, so the new record is immediately visible.
- Expenses with payment status "To define" are now included in the total and shown separately.
- Added "To define" as an expense status filter.
- If the selected period is empty but TEXARI has expense records elsewhere, the app explains this and offers "View all history".
- Empty periods no longer show a large blank chart.
- Document date, due date and payment date are validated before saving.
- Invoices and receipts require a valid amount to be included as financial records.

## V0.4 features retained
- No demo expenses.
- First-run language, currency and date-format setup.
- Paid / to-pay invoice flow, due dates, payment method, payment date and reminders.
- Selectable categories/subcategories plus custom categories.
- Edit/delete expenses, charts, calendar history, filters and exports.
- Recurring expenses, budgets, review inbox, global search and on-device OCR.

Data remains local to the device in this evaluation version; uninstalling the app deletes local data because cloud accounts/sync are not implemented yet.
