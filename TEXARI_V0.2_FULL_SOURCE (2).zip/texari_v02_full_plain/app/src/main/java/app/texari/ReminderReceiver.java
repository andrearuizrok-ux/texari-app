package app.texari;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="texari_payments";
    @Override public void onReceive(Context context,Intent intent){
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;
        if(android.os.Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"TEXARI · Scadenze",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("Promemoria per fatture e pagamenti");nm.createNotificationChannel(ch);}
        String title=intent.getStringExtra("title");String amount=intent.getStringExtra("amount");String due=intent.getStringExtra("due");String kind=intent.getStringExtra("kind");String cur=intent.getStringExtra("currency");
        if(title==null||title.trim().isEmpty())title="Pagamento";if(cur==null)cur="";String when="TODAY".equals(kind)?"Scade oggi":"Scade domani";String body=when+(amount==null||amount.isEmpty()?"":" · "+cur+amount)+(due==null||due.isEmpty()?"":" · "+due);
        Intent open=new Intent(context,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent content=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setColor(Color.rgb(111,99,232)).setContentIntent(content);nm.notify(Math.abs((title+due+kind).hashCode()),b.build());
    }
}
