package app.texari.evaluation;

import org.json.JSONObject;

import java.util.UUID;

public class TexariItem {
    public String id = UUID.randomUUID().toString();
    public String type = "DOCUMENT";
    public String title = "";
    public String date = "";
    public String due = "";
    public String amount = "";
    public String category = "CAT_OTHER";
    public String subcategory = "";
    public String context = "PERSONAL";
    public String status = "SAVED";
    public String source = "";
    public String note = "";
    public String ocr = "";
    public String paymentStatus = "NA";
    public String paymentMethod = "";
    public String paymentDate = "";
    public boolean expense = false;
    public boolean recurring = false;
    public boolean reminderEnabled = true;
    public JSONObject custom = new JSONObject();

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("type", type);
            o.put("title", title);
            o.put("date", date);
            o.put("due", due);
            o.put("amount", amount);
            o.put("category", category);
            o.put("subcategory", subcategory);
            o.put("context", context);
            o.put("status", status);
            o.put("source", source);
            o.put("note", note);
            o.put("ocr", ocr);
            o.put("paymentStatus", paymentStatus);
            o.put("paymentMethod", paymentMethod);
            o.put("paymentDate", paymentDate);
            o.put("expense", expense);
            o.put("recurring", recurring);
            o.put("reminderEnabled", reminderEnabled);
            o.put("custom", custom);
        } catch (Exception ignored) {}
        return o;
    }

    public static TexariItem fromJson(JSONObject o) {
        TexariItem i = new TexariItem();
        i.id = o.optString("id", UUID.randomUUID().toString());
        String legacyType = o.optString("type", "Documento");
        i.type = normalizeType(legacyType);
        i.title = o.optString("title", "");
        i.date = o.optString("date", "");
        i.due = o.optString("due", "");
        i.amount = o.optString("amount", "");
        i.category = normalizeCategory(o.optString("category", "CAT_OTHER"));
        i.subcategory = o.optString("subcategory", "");
        i.context = normalizeContext(o.optString("context", "PERSONAL"));
        i.status = normalizeStatus(o.optString("status", "SAVED"));
        i.source = o.optString("source", "");
        i.note = o.optString("note", "");
        i.ocr = o.optString("ocr", "");
        i.expense = o.optBoolean("expense", false);
        i.recurring = o.optBoolean("recurring", false);
        i.reminderEnabled = o.has("reminderEnabled") ? o.optBoolean("reminderEnabled", true) : true;
        i.custom = o.optJSONObject("custom");
        if (i.custom == null) i.custom = new JSONObject();

        String ps = o.optString("paymentStatus", "");
        if (ps.isEmpty()) {
            String legacyStatus = o.optString("status", "").toLowerCase();
            if (legacyStatus.contains("pagat")) ps = "PAID";
            else if (!i.due.isEmpty() || legacyStatus.contains("da pagare") || legacyStatus.contains("scad")) ps = "PENDING";
            else if (i.type.equals("RECEIPT")) ps = "PAID";
            else if (i.type.equals("INVOICE") && i.expense) ps = "UNKNOWN";
            else ps = "NA";
        }
        i.paymentStatus = normalizePaymentStatus(ps);
        i.paymentMethod = o.optString("paymentMethod", "");
        i.paymentDate = o.optString("paymentDate", "");
        return i;
    }

    private static String normalizeType(String s) {
        String n = s == null ? "" : s.toLowerCase();
        if (n.contains("fatt") || n.contains("invoice")) return "INVOICE";
        if (n.contains("ricev") || n.contains("scontr") || n.contains("receipt")) return "RECEIPT";
        if (n.contains("prenot") || n.contains("booking")) return "BOOKING";
        if (n.contains("nota") || n.contains("note")) return "NOTE";
        if (n.equals("invoice") || n.equals("receipt") || n.equals("booking") || n.equals("document") || n.equals("note")) return n.toUpperCase();
        return "DOCUMENT";
    }

    private static String normalizePaymentStatus(String s) {
        String n = s == null ? "" : s.toUpperCase();
        if (n.contains("PAID") || n.contains("PAGAT")) return "PAID";
        if (n.contains("PENDING") || n.contains("PAGARE") || n.contains("SCAD")) return "PENDING";
        if (n.contains("UNKNOWN") || n.contains("NON SO")) return "UNKNOWN";
        return "NA";
    }

    private static String normalizeStatus(String s) {
        String n = s == null ? "" : s.toLowerCase();
        if (n.contains("rived") || n.contains("review")) return "REVIEW";
        return "SAVED";
    }

    private static String normalizeContext(String s) {
        if (s == null) return "PERSONAL";
        String n = s.toLowerCase();
        if (n.contains("casa") || n.contains("home")) return "HOME";
        if (n.contains("lavor") || n.contains("work")) return "WORK";
        if (n.contains("viagg") || n.contains("travel") || n.contains("roma")) return "TRAVEL";
        if (n.contains("fam")) return "FAMILY";
        if (n.contains("salut") || n.contains("health")) return "HEALTH";
        if (s.startsWith("CUSTOM:")) return s;
        return "PERSONAL";
    }

    public static String normalizeCategory(String s) {
        if (s == null) return "CAT_OTHER";
        if (s.startsWith("CAT_") || s.startsWith("CUSTOM:")) return s;
        String n = s.toLowerCase();
        if (n.contains("uten") || n.contains("casa") || n.contains("home")) return "CAT_HOME";
        if (n.contains("aliment") || n.contains("grocery")) return "CAT_GROCERY";
        if (n.contains("ristor") || n.contains("dining") || n.contains("bar")) return "CAT_DINING";
        if (n.contains("trasport") || n.contains("transport")) return "CAT_TRANSPORT";
        if (n.contains("salut") || n.contains("health")) return "CAT_HEALTH";
        if (n.contains("viagg") || n.contains("travel")) return "CAT_TRAVEL";
        if (n.contains("acquist") || n.contains("shopping")) return "CAT_SHOPPING";
        if (n.contains("abbon") || n.contains("subscription")) return "CAT_SUBSCRIPTIONS";
        if (n.contains("serviz") || n.contains("service")) return "CAT_SERVICES";
        if (n.contains("educ") || n.contains("school")) return "CAT_EDUCATION";
        if (n.contains("lavor") || n.contains("work")) return "CAT_WORK";
        if (n.contains("altro") || n.contains("other")) return "CAT_OTHER";
        return "CUSTOM:" + s;
    }
}
