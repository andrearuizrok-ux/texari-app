# TEXARI V0.7.2 — Documents, simple language, debts & navigation

Evaluation build focused on two structural improvements requested during real testing:

- Debts and installment plans: total debt, upfront payment, number of monthly installments, first due date, who you owe, category, context and payment method. TEXARI generates each future installment and places it in upcoming payments and the financial calendar.
- Debt center with total remaining debt, amount due this month, next installment and remaining installments.
- Installments can be marked paid directly and the remaining debt recalculates automatically.
- Deleting a debt plan also removes its generated installment schedule.
- Android Back now navigates within TEXARI: detail screens return to their parent, top-level Finance/Contexts/Ask return to Home, and Home requires a second Back press to exit.
- Finance/OCR/report features from V0.7 are preserved.
- Firebase Cloud Beta scaffolding from V0.6 is preserved; a real Firebase project configuration is still required to activate cloud sync.


## V0.7.2 — Original document + simpler language
- Every imported photo or PDF is copied into TEXARI private app storage.
- Review and detail screens show the original image/PDF preview together with OCR text.
- The original can be opened from the saved item; lists stay lightweight because full files are loaded only in detail.
- Cloud Beta still syncs structured data only; original document file upload will be added when Firebase Storage is connected.
- Consumer wording simplified: “Proveedores/Fornitori” is now “Dónde gastas/Dove spendi”, and merchant/debt labels use everyday language.
