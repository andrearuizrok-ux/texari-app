package app.texari.evaluation;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Calendar;

public final class MonthlyReportScheduler {
    private MonthlyReportScheduler() {}

    public static void scheduleFromPrefs(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("texari_v02", Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("monthly_report_enabled", false);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pendingIntent(context);
        if (alarm == null) return;
        if (!enabled) {
            alarm.cancel(pi);
            return;
        }

        int day = Math.max(1, Math.min(28, prefs.getInt("monthly_report_day", 1)));
        Calendar now = Calendar.getInstance();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.DAY_OF_MONTH, day);
        next.set(Calendar.HOUR_OF_DAY, 9);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (!next.after(now)) next.add(Calendar.MONTH, 1);
        alarm.setWindow(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), 60L * 60L * 1000L, pi);
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent i = new Intent(context, MonthlyReportReceiver.class);
        return PendingIntent.getBroadcast(context, 70051, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
