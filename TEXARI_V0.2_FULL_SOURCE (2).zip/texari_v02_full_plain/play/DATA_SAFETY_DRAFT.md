# TEXARI — Google Play Data Safety draft

This is a preparation aid, not a substitute for the Play Console questionnaire. Verify every answer against the final binary and Firebase configuration before submission.

## Likely collected data in V0.9
- Email address / account identifier: Firebase Authentication; required for Cloud account and sync.
- User-provided financial information: structured expenses, income, debts, installments, amounts, dates and categories stored in Firestore when Cloud sync is enabled.
- User-provided document text/metadata: OCR text and structured document metadata stored in Firestore when Cloud sync is enabled.
- Original photos/PDFs: local-only in the Spark beta; not uploaded to Firebase Storage.

## Current product statements
- No advertising SDK.
- No sale of user data.
- Cloud data is associated with the authenticated account.
- In-app account deletion exists.
- A public external deletion URL is still required before Play submission.
- A public Privacy Policy URL is still required before Play submission.

Review Firebase SDK data practices in the Google Play SDK Index/Data Safety guidance when filling the form.
