# TEXARI V0.9 Play Beta checklist

## Code completed in this package
- Final applicationId: `app.texari`
- Android 16 target: API 36
- compileSdk 36
- AGP 8.9.1 / Gradle 8.11.1
- versionCode 12 / versionName 0.9.0
- Android App Bundle build task included
- Release signing reads only environment variables; no signing secret is committed
- FileProvider authority follows applicationId
- Android backup disabled for the beta
- In-app Cloud account deletion retained

## Required before Firebase-enabled build
1. In existing Firebase project TEXARI, add Android app `app.texari`.
2. Download its new `google-services.json`.
3. Put it in `app/google-services.json`.

## Required before Google Play upload
- Build a signed `.aab` with the TEXARI upload key.
- Publish Privacy Policy at a stable public URL.
- Publish external account-deletion request page at a stable public URL.
- Complete Data Safety accurately.
- Prepare Play Store screenshots and graphics.
- Create Play Console app and configure testing track.
