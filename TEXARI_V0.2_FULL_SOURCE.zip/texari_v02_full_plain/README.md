# TEXARI V0.6 Cloud Beta

TEXARI V0.6 keeps the complete V0.5 finance/document experience and adds the first real Cloud client plus the new TEXARI launcher identity.

## Android app
- versionName `0.6.0`
- new interlaced-X TEXARI launcher icon (adaptive + legacy)
- Firebase Authentication client: create account, sign in, password reset, sign out, delete account
- Firestore sync/restore for profile, preferences and TEXARI item metadata
- local-first behavior: the app remains fully usable when Firebase is not connected
- Cloud status is explicit; the app never pretends that sync is active

## Activating TEXARI Cloud
Firebase requires a project-specific `app/google-services.json` file and enabled services. The config file identifies the Firebase project; it does not contain the user's password.

1. Create/select the Firebase project for TEXARI.
2. Register Android app package: `app.texari.evaluation`.
3. Download `google-services.json` and place it in `app/google-services.json`.
4. Enable Email/Password Authentication.
5. Create Cloud Firestore and Firebase Storage.
6. Deploy `firebase/firestore.rules` and `firebase/storage.rules`.
7. Rebuild the APK. The Gradle build automatically enables the Google Services plugin when the config file is present.

## Automatic monthly reports
The `firebase/functions` folder contains the Cloud Functions backend scaffold for server-side monthly report delivery. It uses a daily Firebase scheduled function, generates PDF/XLSX/CSV, and sends the attachment through Resend.

Before deploying it, configure Firebase Functions secrets `RESEND_API_KEY` and `TEXARI_FROM_EMAIL`, then deploy the functions. Server-side delivery is intentionally not simulated in the APK: it only becomes active once the backend is deployed.

## Current Cloud Beta boundary
V0.6 syncs structured TEXARI data and preferences. The original imported photo/PDF bytes remain on-device in this beta; the Storage dependency and rules are included for the next file-upload increment.
