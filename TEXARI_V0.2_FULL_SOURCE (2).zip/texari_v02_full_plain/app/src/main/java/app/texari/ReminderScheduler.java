package app.texari;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReminderScheduler {
    public static void schedule(Context context, TexariItem item, String dateFormat, String currencyLabel) {
        cancel(context,item.id);
        if(item==null || !item.reminderEnabled || !"PENDING".equals(item.paymentStatus) || item.due==null || item.due.trim().isEmpty()) return;
        Date due=parseDate(item.due,dateFormat); if(due==null)return;
        Calendar dueCal=Calendar.getInstance(); dueCal.setTime(due); dueCal.set(Calendar.HOUR_OF_DAY,9);dueCal.set(Calendar.MINUTE,0);dueCal.set(Calendar.SECOND,0);dueCal.set(Calendar.MILLISECOND,0);
        long now=System.currentTimeMillis();
        Calendar before=(Calendar)dueCal.clone(); before.add(Calendar.DAY_OF_MONTH,-1);
        if(before.getTimeInMillis()>now) set(context,item,before.getTimeInMillis(),0,"TOMORROW",currencyLabel);
        if(dueCal.getTimeInMillis()>now) set(context,item,dueCal.getTimeInMillis(),1,"TODAY",currencyLabel);
    }
    public static void cancel(Context context,String id){
        if(id==null)return; AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        for(int k=0;k<2;k++){Intent in=new Intent(context,ReminderReceiver.class);in.setAction("app.texari.PAYMENT_REMINDER."+id+"."+k);PendingIntent pi=PendingIntent.getBroadcast(context,requestCode(id,k),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
    }
    private static void set(Context context,TexariItem item,long when,int index,String kind,String currencyLabel){
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(am==null)return;Intent in=new Intent(context,ReminderReceiver.class);in.setAction("app.texari.PAYMENT_REMINDER."+item.id+"."+index);in.putExtra("title",item.title);in.putExtra("amount",item.amount);in.putExtra("due",item.due);in.putExtra("kind",kind);in.putExtra("currency",currencyLabel);PendingIntent pi=PendingIntent.getBroadcast(context,requestCode(item.id,index),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.set(AlarmManager.RTC_WAKEUP,when,pi);
    }
    private static int requestCode(String id,int k){return (id.hashCode()*31+k)&0x7fffffff;}
    private static Date parseDate(String s,String format){
        String[] patterns="MDY".equals(format)?new String[]{"MM/dd/yyyy","M/d/yyyy","dd/MM/yyyy","yyyy-MM-dd"}:new String[]{"dd/MM/yyyy","d/M/yyyy","MM/dd/yyyy","yyyy-MM-dd"};
        for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setLenient(false);return f.parse(s.trim());}catch(Exception ignored){}}
        return null;
    }
}
