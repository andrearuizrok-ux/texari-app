const {onSchedule} = require("firebase-functions/v2/scheduler");
const {defineSecret} = require("firebase-functions/params");
const {logger} = require("firebase-functions");
const admin = require("firebase-admin");
const PDFDocument = require("pdfkit");
const ExcelJS = require("exceljs");

admin.initializeApp();
const db = admin.firestore();
const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const TEXARI_FROM_EMAIL = defineSecret("TEXARI_FROM_EMAIL");

function localParts(timeZone) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: timeZone || "UTC",
    year: "numeric", month: "2-digit", day: "2-digit"
  });
  const parts = Object.fromEntries(fmt.formatToParts(new Date()).filter(p => p.type !== "literal").map(p => [p.type, p.value]));
  return {year: Number(parts.year), month: Number(parts.month), day: Number(parts.day)};
}

function previousMonth(y, m) {
  if (m === 1) return {year: y - 1, month: 12};
  return {year: y, month: m - 1};
}

function parseDate(s, dateFormat) {
  if (!s) return null;
  const parts = String(s).trim().replace(/[.-]/g, "/").split("/").map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) return null;
  let y, m, d;
  if (parts[0] > 1900) { y = parts[0]; m = parts[1]; d = parts[2]; }
  else if (dateFormat === "MDY") { m = parts[0]; d = parts[1]; y = parts[2]; }
  else { d = parts[0]; m = parts[1]; y = parts[2]; }
  if (y < 100) y += y >= 70 ? 1900 : 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  return {year: y, month: m, day: d};
}

function amount(v) {
  if (typeof v === "number") return v;
  let x = String(v || "").replace(/[^0-9,.-]/g, "");
  if (!x) return 0;
  const comma = x.lastIndexOf(","), dot = x.lastIndexOf(".");
  if (comma >= 0 && dot >= 0) x = comma > dot ? x.replace(/\./g, "").replace(",", ".") : x.replace(/,/g, "");
  else if (comma >= 0) x = x.length - comma - 1 === 2 ? x.replace(",", ".") : x.replace(/,/g, "");
  else if (dot >= 0 && x.length - dot - 1 !== 2) x = x.replace(/\./g, "");
  const n = Number(x); return Number.isFinite(n) ? n : 0;
}

function categoryLabel(code, lang) {
  const map = {
    CAT_HOME:["Casa e utenze","Casa y servicios","Home & utilities"], CAT_GROCERY:["Alimentari","Alimentación","Groceries"],
    CAT_DINING:["Ristoranti","Restaurantes","Dining"], CAT_TRANSPORT:["Trasporti","Transporte","Transport"],
    CAT_HEALTH:["Salute","Salud","Health"], CAT_TRAVEL:["Viaggi","Viajes","Travel"], CAT_SHOPPING:["Acquisti","Compras","Shopping"],
    CAT_SUBSCRIPTIONS:["Abbonamenti","Suscripciones","Subscriptions"], CAT_SERVICES:["Servizi","Servicios","Services"],
    CAT_EDUCATION:["Educazione","Educación","Education"], CAT_WORK:["Lavoro","Trabajo","Work"], CAT_OTHER:["Altro","Otros","Other"]
  };
  if (String(code || "").startsWith("CUSTOM:")) return String(code).slice(7);
  const v = map[code] || map.CAT_OTHER; return lang === "ES" ? v[1] : lang === "EN" ? v[2] : v[0];
}

function currPrefix(c) {
  return ({EUR:"€ ",USD:"US$ ",GBP:"£ ",VES:"Bs ",ARS:"ARS $ ",COP:"COP $ ",MXN:"MX$ "})[c] || `${c || ""} `;
}

function reportData(user, period) {
  let raw = [];
  try { raw = JSON.parse(user.itemsJson || "[]"); } catch (_) {}
  const rows = raw.filter(i => i.expense && amount(i.amount) > 0).filter(i => {
    const d = parseDate(i.date, user.dateFormat || "DMY");
    return d && d.year === period.year && d.month === period.month;
  });
  let paid = 0, pending = 0, unknown = 0;
  const cats = new Map();
  for (const i of rows) {
    const a = amount(i.amount);
    if (i.paymentStatus === "PAID") paid += a;
    else if (i.paymentStatus === "PENDING") pending += a;
    else unknown += a;
    cats.set(i.category || "CAT_OTHER", (cats.get(i.category || "CAT_OTHER") || 0) + a);
  }
  return {rows, paid, pending, unknown, total: paid + pending + unknown, cats};
}

function csvBuffer(user, period, data) {
  const header = "Date,Title,Category,Amount,Currency,Payment status,Due date,Method\n";
  const esc = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const lines = data.rows.map(i => [i.date,i.title,categoryLabel(i.category,user.language),amount(i.amount).toFixed(2),user.currency,i.paymentStatus,i.due,i.paymentMethod].map(esc).join(","));
  return Buffer.from(header + lines.join("\n"), "utf8");
}

async function xlsxBuffer(user, period, data) {
  const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet("TEXARI");
  ws.addRow(["TEXARI", `${period.year}-${String(period.month).padStart(2,"0")}`]);
  ws.addRow(["Total", data.total, "Paid", data.paid, "Due", data.pending]);
  ws.addRow([]); ws.addRow(["Date","Title","Category","Amount","Currency","Status","Due","Method"]);
  for (const i of data.rows) ws.addRow([i.date,i.title,categoryLabel(i.category,user.language),amount(i.amount),user.currency,i.paymentStatus,i.due,i.paymentMethod]);
  return Buffer.from(await wb.xlsx.writeBuffer());
}

function pdfBuffer(user, period, data) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({margin: 42}); const chunks = [];
    doc.on("data", c => chunks.push(c)); doc.on("end", () => resolve(Buffer.concat(chunks))); doc.on("error", reject);
    doc.fontSize(24).text("TEXARI"); doc.fontSize(11).fillColor("#666").text("Everything, in context."); doc.moveDown();
    doc.fillColor("#111C31").fontSize(17).text(`${period.year}-${String(period.month).padStart(2,"0")}`);
    doc.fontSize(14).text(`Total: ${currPrefix(user.currency)}${data.total.toFixed(2)}`);
    doc.fontSize(11).text(`Paid: ${currPrefix(user.currency)}${data.paid.toFixed(2)}   Due: ${currPrefix(user.currency)}${data.pending.toFixed(2)}   To define: ${currPrefix(user.currency)}${data.unknown.toFixed(2)}`);
    doc.moveDown(); doc.fontSize(13).text("Categories");
    [...data.cats.entries()].sort((a,b)=>b[1]-a[1]).forEach(([c,v]) => doc.fontSize(10).text(`${categoryLabel(c,user.language)}: ${currPrefix(user.currency)}${v.toFixed(2)}`));
    doc.moveDown(); doc.fontSize(13).text("Transactions");
    for (const i of data.rows) doc.fontSize(9).text(`${i.date || ""}  ${i.title || ""}  ${categoryLabel(i.category,user.language)}  ${currPrefix(user.currency)}${amount(i.amount).toFixed(2)}  ${i.paymentStatus || ""}`);
    doc.end();
  });
}

async function sendResend(to, subject, html, filename, buffer, mime) {
  const key = RESEND_API_KEY.value(); const from = TEXARI_FROM_EMAIL.value();
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST", headers: {Authorization: `Bearer ${key}`, "Content-Type": "application/json"},
    body: JSON.stringify({from, to:[to], subject, html, attachments:[{filename, content:buffer.toString("base64"), content_type:mime}]})
  });
  if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
}

exports.monthlyTexariReports = onSchedule({schedule:"0 7 * * *", secrets:[RESEND_API_KEY, TEXARI_FROM_EMAIL], timeoutSeconds:540}, async () => {
  const snap = await db.collection("users").where("reportEnabled","==",true).get();
  for (const doc of snap.docs) {
    const u = doc.data(); const lp = localParts(u.timezone || "UTC");
    if (lp.day !== Number(u.reportDay || 1)) continue;
    const period = previousMonth(lp.year, lp.month); const periodKey = `${period.year}-${String(period.month).padStart(2,"0")}`;
    if (u.lastReportPeriod === periodKey) continue;
    const to = u.reportEmail || u.email; if (!to) continue;
    try {
      const data = reportData(u, period); const format = (u.reportFormat || "PDF").toUpperCase();
      let buf, filename, mime;
      if (format === "XLS" || format === "XLSX") {buf = await xlsxBuffer(u,period,data); filename=`TEXARI_${periodKey}.xlsx`; mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";}
      else if (format === "CSV") {buf=csvBuffer(u,period,data); filename=`TEXARI_${periodKey}.csv`; mime="text/csv";}
      else {buf=await pdfBuffer(u,period,data); filename=`TEXARI_${periodKey}.pdf`; mime="application/pdf";}
      const subject = u.language === "ES" ? `TEXARI · Tu reporte de ${periodKey}` : u.language === "EN" ? `TEXARI · Your ${periodKey} report` : `TEXARI · Il tuo report ${periodKey}`;
      const html = `<div style="font-family:Arial,sans-serif;color:#111C31"><h2>TEXARI</h2><p>${periodKey}</p><p><strong>${currPrefix(u.currency)}${data.total.toFixed(2)}</strong> total · ${data.rows.length} transactions</p><p>Your detailed report is attached.</p></div>`;
      await sendResend(to,subject,html,filename,buf,mime);
      await doc.ref.set({lastReportPeriod:periodKey,lastReportSentAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});
    } catch (e) { logger.error("Monthly TEXARI report failed", {uid:doc.id,error:String(e)}); }
  }
});
