package app.texari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ExpenseChartView extends View {
    public interface OnSelectionListener { void onSelected(String key, boolean isDay); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] colors = new int[]{
            Color.rgb(111,99,232), Color.rgb(49,119,96), Color.rgb(224,145,69),
            Color.rgb(64,128,187), Color.rgb(195,88,112), Color.rgb(126,91,158),
            Color.rgb(79,151,153), Color.rgb(182,111,69), Color.rgb(103,115,128),
            Color.rgb(146,139,72), Color.rgb(92,139,82), Color.rgb(166,91,91)
    };

    private LinkedHashMap<String, Double> categoryData = new LinkedHashMap<>();
    private LinkedHashMap<String, Double> dayData = new LinkedHashMap<>();
    private String mode = "PIE";
    private OnSelectionListener listener;

    public ExpenseChartView(Context context) {
        super(context);
        textPaint.setColor(Color.rgb(104,111,122));
        textPaint.setTextSize(12 * getResources().getDisplayMetrics().scaledDensity);
        setMinimumHeight((int)(240 * getResources().getDisplayMetrics().density));
        setClickable(true);
    }

    public void setMode(String mode) { this.mode = mode == null ? "PIE" : mode; invalidate(); }
    public void setCategoryData(Map<String,Double> data) { categoryData = new LinkedHashMap<>(data); invalidate(); }
    public void setDayData(Map<String,Double> data) { dayData = new LinkedHashMap<>(data); invalidate(); }
    public void setOnSelectionListener(OnSelectionListener l) { listener = l; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.TRANSPARENT);
        if (mode.equals("LINE")) drawLine(canvas); else if (mode.equals("BAR")) drawBars(canvas); else drawPie(canvas);
    }

    private void empty(Canvas c) {
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(14 * getResources().getDisplayMetrics().scaledDensity);
        c.drawText("—", getWidth()/2f, getHeight()/2f, textPaint);
    }

    private void drawPie(Canvas c) {
        if (categoryData.isEmpty()) { empty(c); return; }
        double total = 0; for (double v : categoryData.values()) total += Math.max(0,v);
        if (total <= 0) { empty(c); return; }
        float size = Math.min(getWidth(), getHeight()) * .72f;
        float left = (getWidth()-size)/2f, top = (getHeight()-size)/2f;
        RectF r = new RectF(left, top, left+size, top+size);
        float start = -90;
        int idx=0;
        for (Map.Entry<String,Double> e:categoryData.entrySet()) {
            float sweep = (float)(360.0 * e.getValue()/total);
            paint.setColor(colors[idx % colors.length]);
            c.drawArc(r,start,sweep,true,paint);
            start += sweep; idx++;
        }
        paint.setColor(Color.WHITE);
        float hole=size*.46f;
        c.drawCircle(getWidth()/2f,getHeight()/2f,hole/2f,paint);
        textPaint.setColor(Color.rgb(21,32,50)); textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(12*getResources().getDisplayMetrics().scaledDensity);
        c.drawText(categoryData.size()+" cat.",getWidth()/2f,getHeight()/2f+5*getResources().getDisplayMetrics().density,textPaint);
    }

    private void drawBars(Canvas c) {
        if (categoryData.isEmpty()) { empty(c); return; }
        double max=0; for(double v:categoryData.values()) max=Math.max(max,v); if(max<=0){empty(c);return;}
        float d=getResources().getDisplayMetrics().density;
        float left=18*d,right=12*d,top=16*d,bottom=38*d;
        float usableW=getWidth()-left-right, usableH=getHeight()-top-bottom;
        int n=categoryData.size(); float slot=usableW/Math.max(1,n); int idx=0;
        for(Map.Entry<String,Double> e:categoryData.entrySet()){
            float bh=(float)(usableH*(e.getValue()/max));
            float x=left+idx*slot+slot*.18f;
            paint.setColor(colors[idx%colors.length]);
            c.drawRoundRect(new RectF(x,top+usableH-bh,x+slot*.64f,top+usableH),7*d,7*d,paint);
            textPaint.setColor(Color.rgb(104,111,122));textPaint.setTextAlign(Paint.Align.CENTER);textPaint.setTextSize(9*getResources().getDisplayMetrics().scaledDensity);
            String lab=e.getKey(); if(lab.length()>5)lab=lab.substring(0,5)+"…";
            c.drawText(lab,x+slot*.32f,getHeight()-14*d,textPaint);
            idx++;
        }
    }

    private void drawLine(Canvas c) {
        if (dayData.isEmpty()) { empty(c); return; }
        double max=0; for(double v:dayData.values())max=Math.max(max,v); if(max<=0){empty(c);return;}
        float d=getResources().getDisplayMetrics().density;
        float left=24*d,right=18*d,top=20*d,bottom=35*d;
        float w=getWidth()-left-right,h=getHeight()-top-bottom;
        List<Map.Entry<String,Double>> es=new ArrayList<>(dayData.entrySet());
        paint.setStrokeWidth(3*d);paint.setStyle(Paint.Style.STROKE);paint.setColor(colors[0]);
        float prevX=0,prevY=0;
        for(int i=0;i<es.size();i++){
            float x=left+(es.size()==1?w/2f:(w*i/(es.size()-1f)));
            float y=top+h-(float)(h*(es.get(i).getValue()/max));
            if(i>0)c.drawLine(prevX,prevY,x,y,paint);
            prevX=x;prevY=y;
        }
        paint.setStyle(Paint.Style.FILL);
        for(int i=0;i<es.size();i++){
            float x=left+(es.size()==1?w/2f:(w*i/(es.size()-1f)));
            float y=top+h-(float)(h*(es.get(i).getValue()/max));
            paint.setColor(colors[0]);c.drawCircle(x,y,5*d,paint);
            if(i==0||i==es.size()-1||es.size()<=8){textPaint.setColor(Color.rgb(104,111,122));textPaint.setTextAlign(Paint.Align.CENTER);textPaint.setTextSize(9*getResources().getDisplayMetrics().scaledDensity);c.drawText(es.get(i).getKey(),x,getHeight()-12*d,textPaint);}
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()!=MotionEvent.ACTION_UP) return true;
        if(listener==null) return true;
        if(mode.equals("LINE")) selectLine(event.getX());
        else if(mode.equals("BAR")) selectBar(event.getX());
        else selectPie(event.getX(),event.getY());
        performClick(); return true;
    }

    @Override public boolean performClick(){ super.performClick(); return true; }

    private void selectBar(float x){
        if(categoryData.isEmpty())return; float d=getResources().getDisplayMetrics().density;float left=18*d,right=12*d;float w=getWidth()-left-right;if(x<left||x>getWidth()-right)return;int n=categoryData.size();int idx=(int)((x-left)/(w/n));idx=Math.max(0,Math.min(n-1,idx));listener.onSelected(new ArrayList<>(categoryData.keySet()).get(idx),false);
    }
    private void selectLine(float x){
        if(dayData.isEmpty())return;float d=getResources().getDisplayMetrics().density;float left=24*d,right=18*d,w=getWidth()-left-right;if(x<left||x>getWidth()-right)return;int n=dayData.size();int idx=n==1?0:Math.round((x-left)/w*(n-1));idx=Math.max(0,Math.min(n-1,idx));listener.onSelected(new ArrayList<>(dayData.keySet()).get(idx),true);
    }
    private void selectPie(float x,float y){
        if(categoryData.isEmpty())return;float dx=x-getWidth()/2f,dy=y-getHeight()/2f;double angle=Math.toDegrees(Math.atan2(dy,dx))+90;if(angle<0)angle+=360;double total=0;for(double v:categoryData.values())total+=v;double acc=0;for(Map.Entry<String,Double> e:categoryData.entrySet()){acc+=360*e.getValue()/total;if(angle<=acc){listener.onSelected(e.getKey(),false);return;}}
    }
}
