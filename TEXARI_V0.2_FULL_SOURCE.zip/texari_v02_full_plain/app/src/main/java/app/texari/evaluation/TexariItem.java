package app.texari.evaluation;

import org.json.JSONObject;

import java.util.UUID;

public class TexariItem {
    public String id = UUID.randomUUID().toString();
    public String type = "DOCUMENT";
    public String title = "";
    public String date = "";
    public String due = "";
    public String amount = "";
    public String category = "CAT_OTHER";
    public String subcategory = "";
    public String context = "PERSONAL";
    public String status = "SAVED";
    public String source = "";
    public String note = "";
    public String ocr = "";
    // Original document stored privately on-device (V0.7.2)
    public String documentFile = "";
    public String documentMime = "";
    public String documentOriginalName = "";
    public String paymentStatus = "NA";
    public String paymentMethod = "";
    public String paymentDate = "";
    public String transactionKind = "NA"; // EXPENSE, INCOME, NA
    public String merchant = "";
    public String invoiceNumber = "";
    public String taxAmount = "";
    public int confidence = 0;
    public boolean expense = false;
    public boolean recurring = false;
    public boolean reminderEnabled = true;

    // Debt / installment plan metadata (V0.7.1)
    public boolean debtPlan = false;
    public boolean debtInstallment = false;
    public String parentDebtId = "";
    public String debtTotal = "";
    public int installmentsTotal = 0;
    public int installmentNumber = 0;
    public String debtFrequency = "MONTHLY";
    public String debtStartDate = "";
    public JSONObject custom = new JSONObject();

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("type", type);
            o.put("title", title);
            o.put("date", date);
            o.put("due", due);
            o.put("amount", amount);
            o.put("category", category);
            o.put("subcategory", subcategory);
            o.put("context", context);
            o.put("status", status);
            o.put("source", source);
            o.put("note", note);
            o.put("ocr", ocr);
            o.put("documentFile", documentFile);
            o.put("documentMime", documentMime);
            o.put("documentOriginalName", documentOriginalName);
            o.put("paymentStatus", paymentStatus);
            o.put("paymentMethod", paymentMethod);
            o.put("paymentDate", paymentDate);
            o.put("transactionKind", transactionKind);
            o.put("merchant", merchant);
            o.put("invoiceNumber", invoiceNumber);
            o.put("taxAmount", taxAmount);
            o.put("confidence", confidence);
            o.put("expense", expense);
            o.put("recurring", recurring);
            o.put("reminderEnabled", reminderEnabled);
            o.put("debtPlan", debtPlan);
            o.put("debtInstallment", debtInstallment);
            o.put("parentDebtId", parentDebtId);
            o.put("debtTotal", debtTotal);
            o.put("installmentsTotal", installmentsTotal);
            o.put("installmentNumber", installmentNumber);
            o.put("debtFrequency", debtFrequency);
            o.put("debtStartDate", debtStartDate);
            o.put("custom", custom);
        } catch (Exception ignored) {}
        return o;
    }

    public static TexariItem fromJson(JSONObject o) {
        TexariItem i = new TexariItem();
        i.id = o.optString("id", UUID.randomUUID().toString());
        String legacyType = o.optString("type", "Documento");
        i.type = normalizeType(legacyType);
        i.title = o.optString("title", "");
        i.date = o.optString("date", "");
        i.due = o.optString("due", "");
        i.amount = o.optString("amount", "");
        i.category = normalizeCategory(o.optString("category", "CAT_OTHER"));
        i.subcategory = o.optString("subcategory", "");
        i.context = normalizeContext(o.optString("context", "PERSONAL"));
        i.status = normalizeStatus(o.optString("status", "SAVED"));
        i.source = o.optString("source", "");
        i.note = o.optString("note", "");
        i.ocr = o.optString("ocr", "");
        i.documentFile = o.optString("documentFile", "");
        i.documentMime = o.optString("documentMime", "");
        i.documentOriginalName = o.optString("documentOriginalName", "");
        i.expense = o.optBoolean("expense", false);
        i.recurring = o.optBoolean("recurring", false);
        i.reminderEnabled = o.has("reminderEnabled") ? o.optBoolean("reminderEnabled", true) : true;
        i.debtPlan = o.optBoolean("debtPlan", false);
        i.debtInstallment = o.optBoolean("debtInstallment", false);
        i.parentDebtId = o.optString("parentDebtId", "");
        i.debtTotal = o.optString("debtTotal", "");
        i.installmentsTotal = o.optInt("installmentsTotal", 0);
        i.installmentNumber = o.optInt("installmentNumber", 0);
        i.debtFrequency = o.optString("debtFrequency", "MONTHLY");
        i.debtStartDate = o.optString("debtStartDate", "");
        i.custom = o.optJSONObject("custom");
        if (i.custom == null) i.custom = new JSONObject();

        String ps = o.optString("paymentStatus", "");
        if (ps.isEmpty()) {
            String legacyStatus = o.optString("status", "").toLowerCase();
            if (legacyStatus.contains("pagat")) ps = "PAID";
            else if (!i.due.isEmpty() || legacyStatus.contains("da pagare") || legacyStatus.contains("scad")) ps = "PENDING";
            else if (i.type.equals("RECEIPT")) ps = "PAID";
            else if (i.type.equals("INVOICE") && i.expense) ps = "UNKNOWN";
            else ps = "NA";
        }
        i.paymentStatus = normalizePaymentStatus(ps);
        i.paymentMethod = o.optString("paymentMethod", "");
        i.paymentDate = o.optString("paymentDate", "");
        i.transactionKind = o.optString("transactionKind", i.expense ? "EXPENSE" : ("INCOME".equals(i.type) ? "INCOME" : "NA"));
        if (!"EXPENSE".equals(i.transactionKind) && !"INCOME".equals(i.transactionKind)) i.transactionKind = i.expense ? "EXPENSE" : "NA";
        i.merchant = o.optString("merchant", i.title);
        i.invoiceNumber = o.optString("invoiceNumber", "");
        i.taxAmount = o.optString("taxAmount", "");
        i.confidence = o.optInt("confidence", 0);
        i.expense = "EXPENSE".equals(i.transactionKind);
        return i;
    }

    private static String normalizeType(String s) {
        String n = s == null ? "" : s.toLowerCase();
        if (n.contains("fatt") || n.contains("invoice")) return "INVOICE";
        if (n.contains("ricev") || n.contains("scontr") || n.contains("receipt")) return "RECEIPT";
        if (n.contains("debito") || n.contains("deuda") || n.equals("debt")) return "DEBT";
        if (n.contains("rata") || n.contains("cuota") || n.contains("installment")) return "INSTALLMENT";
        if (n.contains("entrata") || n.contains("ingreso") || n.contains("income")) return "INCOME";
        if (n.contains("prenot") || n.contains("booking")) return "BOOKING";
        if (n.contains("nota") || n.contains("note")) return "NOTE";
        if (n.equals("invoice") || n.equals("receipt") || n.equals("booking") || n.equals("document") || n.equals("note")) return n.toUpperCase();
        return "DOCUMENT";
    }

    private static String normalizePaymentStatus(String s) {
        String n = s == null ? "" : s.toUpperCase();
        if (n.contains("PAID") || n.contains("PAGAT")) return "PAID";
        if (n.contains("PENDING") || n.contains("PAGARE") || n.contains("SCAD")) return "PENDING";
        if (n.contains("UNKNOWN") || n.contains("NON SO")) return "UNKNOWN";
        return "NA";
    }

    private static String normalizeStatus(String s) {
        String n = s == null ? "" : s.toLowerCase();
        if (n.contains("rived") || n.contains("review")) return "REVIEW";
        return "SAVED";
    }

    private static String normalizeContext(String s) {
        if (s == null) return "PERSONAL";
        String n = s.toLowerCase();
        if (n.contains("casa") || n.contains("home")) return "HOME";
        if (n.contains("lavor") || n.contains("work")) return "WORK";
        if (n.contains("viagg") || n.contains("travel") || n.contains("roma")) return "TRAVEL";
        if (n.contains("fam")) return "FAMILY";
        if (n.contains("salut") || n.contains("health")) return "HEALTH";
        if (s.startsWith("CUSTOM:")) return s;
        return "PERSONAL";
    }

    public static String normalizeCategory(String s) {
        if (s == null) return "CAT_OTHER";
        if (s.startsWith("CAT_") || s.startsWith("CUSTOM:")) return s;
        String n = s.toLowerCase();
        if (n.contains("uten") || n.contains("casa") || n.contains("home")) return "CAT_HOME";
        if (n.contains("aliment") || n.contains("grocery")) return "CAT_GROCERY";
        if (n.contains("ristor") || n.contains("dining") || n.contains("bar")) return "CAT_DINING";
        if (n.contains("trasport") || n.contains("transport")) return "CAT_TRANSPORT";
        if (n.contains("salut") || n.contains("health")) return "CAT_HEALTH";
        if (n.contains("viagg") || n.contains("travel")) return "CAT_TRAVEL";
        if (n.contains("acquist") || n.contains("shopping")) return "CAT_SHOPPING";
        if (n.contains("abbon") || n.contains("subscription")) return "CAT_SUBSCRIPTIONS";
        if (n.contains("serviz") || n.contains("service")) return "CAT_SERVICES";
        if (n.contains("educ") || n.contains("school")) return "CAT_EDUCATION";
        if (n.contains("lavor") || n.contains("work")) return "CAT_WORK";
        if (n.contains("altro") || n.contains("other")) return "CAT_OTHER";
        return "CUSTOM:" + s;
    }
}
